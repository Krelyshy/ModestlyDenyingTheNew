// Redirect
window.location.hostname = "mdn1.moz.one";
